$.fn.memeGenerator("i18n", "pl", {
	topTextPlaceholder: "GÓRNY TEKST",
	bottomTextPlaceholder: "DOLNY TEKST",
	
	addTextbox: "Dodaj pole tekstowe",
	advancedSettings: "Zaawansowane opcje",
	toolbox: "Rysowanie",
	
	optionCapitalLetters: "Używaj tylko wielkich liter",
	optionDragResize: "Włącz interaktywne przemieszczanie i skalowanie pól tekstowych",
	optionDrawingAboveText: "Pokazuj rysunek ponad tekstem",

	drawingStart: "Rysuj",
	drawingStop: "Przestań rysować",
	drawingErase: "Wyczyść",
});